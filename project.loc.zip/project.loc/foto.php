<?php

$fotos = [
    ['title' => 'Title', 'slug Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'img' => 'img/pic4.jpg'],
    ['title' => 'Title', 'slug Lorem ipsum dolor sit amet, consectetur adipisicing elit.','img' => 'img/pic5.jpg'],
    ['title' => 'Title', 'slug Lorem ipsum dolor sit amet, consectetur adipisicing elit.','img' => 'img/pic6.jpg'],
    ['title' => 'Title', 'slug Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'img' => 'img/pic7.jpg'],
    ['title' => 'Title', 'slug Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'img' => 'img/pic8.jpg'],
    ['title' => 'Title', 'slug Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'img' => 'img/pic9.jpg']
];
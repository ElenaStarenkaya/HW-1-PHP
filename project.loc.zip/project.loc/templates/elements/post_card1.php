<div class="wrapper">
        <div class="content">
            <div class="content__text">
                <div>
                    <h3 class="h3"><?php echo $title ?></h3>
                    <p class="p1">
                        <?php echo $slug ?>
                        </p>
                    <!-- <p class="p2">
                        Далеко-далеко за словесными горами в стране гласных и согласных живут рыбные тексты. Пояс гор
                        сбить прямо имеет ему пор залетают коварный проектах.
                        </p2> -->
                </div>
                <div>
                    <button class="btn_1">START</button>
                </div>
            </div>
            <div class="content__image" style="width: 50%;">
                <img src="<?php echo $img ?>" />
            </div>
        </div>
    </div>
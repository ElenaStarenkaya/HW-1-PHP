<header class="wrapper">
        <nav class="nav">
            <menu class="menu">
                <ul class="navbar">
                    <li><a href="/" class="logo"><strong>TOUR-GUIDE</strong></a></li>
                    <li><a href="/stories.php">Stories</a></li>
                    <li><a href="">Gallery</a></li>
                    <li><a href="">Features</a></li>
                    <li><a href="">Write to us</a></li>
                </ul>
            </menu>

            <ul class="social-icons-1">
                <li><a href="http://www.twitter.com"><img src="img/twitter-128.png" /></a></li>
                <li><a href="http://www.facebook.com"><img src="img/facebook-128.png" /></a></li>
                <li><a href="http://www.instagram.com"><img src="img/instagram-2-128.png" /></a></li>
                <li><a href="http://www.youtube.com"><img src="img/youtube-128.png" /></a></li>
                <li><a href="http://www.gmail.com"><img src="img/gmail-128.png" /></a></li>
            </ul>
        </nav>
    </header>

    <hr>
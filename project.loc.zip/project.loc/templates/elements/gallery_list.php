<?php



foreach($fotos as $key => $foto) {
    // if($key % 2 == 0){  
echo get_template('./templates/elements/gallery.php', $foto);
    // }
    // else {
    //     echo get_template('./templates/elements/post_card2.php', $post);
    // }
}
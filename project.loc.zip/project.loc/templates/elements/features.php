<div class="wrapper">
        <div class="features">
            <h2>Features</h2>
            <div class="grid">
                <div class="item_1">
                    <img src="img/airplane-48.png" alt="">
                    <div class="grid_text_1">
                        <h4>One</h4>
                    </div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet, veritatis.</p>
                </div>
                <div class="item_2">
                    <img src="img/map_marker-48.png" alt="">
                    <div class="grid_text_2">
                        <h4>Two</h4>
                    </div>
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit, rerum.</p>
                </div>
                <div class="item_3">
                    <img src="img/movie-48.png" alt="">
                    <div class="grid_text_3">
                        <h4>Three</h4>
                    </div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet, veritatis.</p>
                </div>
                <div class="item_4">
                    <img src="img/alarm_clock-48.png" alt="">
                    <div class="grid_text_4">
                        <h4>Four</h4>
                    </div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet, veritatis.</p>
                </div>
                <div class="item_5">
                    <img src="img/face-48.png" alt="">
                    <div class="grid_text_5">
                        <h4>Five</h4>
                    </div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet, veritatis.</p>
                </div>
                <div class="item_6">
                    <img src="img/genius-48.png" alt="">
                    <div class="grid_text_6">
                        <h4>Six</h4>
                    </div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet, veritatis.</p>
                </div>
            </div>
        </div>
</div>
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travelblog</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="OwlCarousel2-2.3.4/dist/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="OwlCarousel2-2.3.4/dist/assets/owl.theme.default.min.css">
    <link rel="shortcut icon" href="img/favicon.ico">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:wght@500&display=swap" rel="stylesheet">

</head>

<body>

<?php echo $page ?>





    <!-- <header class="wrapper">
        <nav class="nav">
            <menu class="menu">
                <ul class="navbar">
                    <li><a href="" class="logo"><strong>TOUR-GUIDE</strong></a></li>
                    <li><a href="">Stories</a></li>
                    <li><a href="">Gallery</a></li>
                    <li><a href="">Features</a></li>
                    <li><a href="">Write to us</a></li>
                </ul>
            </menu>

            <ul class="social-icons-1">
                <li><a href="http://www.twitter.com"><img src="img/twitter-128.png" /></a></li>
                <li><a href="http://www.facebook.com"><img src="img/facebook-128.png" /></a></li>
                <li><a href="http://www.instagram.com"><img src="img/instagram-2-128.png" /></a></li>
                <li><a href="http://www.youtube.com"><img src="img/youtube-128.png" /></a></li>
                <li><a href="http://www.gmail.com"><img src="img/gmail-128.png" /></a></li>
            </ul>
        </nav>
    </header>

    <hr> -->

    <!-- <div class="wrapper">
        <div class="content">
            <div class="content__text">
                <div>
                    <h3 class="h3">Let's hit the Road</h3>
                    <p class="p1">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa pariatur ab ducimus explicabo
                        laboriosam accusamus reiciendis!
                        </p1>
                    <p class="p2">
                        Далеко-далеко за словесными горами в стране гласных и согласных живут рыбные тексты. Пояс гор
                        сбить прямо имеет ему пор залетают коварный проектах.
                        </p2>
                </div>
                <div>
                    <button class="btn_1">START</button>
                </div>
            </div>
            <div class="content__image" style="width: 50%;">
                <img src="img/pic1.jpg" alt="" />
            </div>
        </div>
    </div> -->

    <!-- <div class="wrapper">
        <div class="content">
            <div class="content__image" style="width: 40%;">
                <img src="img/pic2.jpg" alt="" />
            </div>
            <div class="content__text">
                <div>
                    <h3 class="h3">Story</h3>
                    <p class="p1">
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nisi quo veniam magni dolor nobis.
                        Commodi natus enim sed, eius dolore aliquam eos numquam praesentium eum cupiditate, neque ipsum
                        est vel delectus officiis omnis dolor ea. Ipsa deserunt minus suscipit. Doloremque, ipsum
                        molestiae rerum sed sunt natus perspiciatis. Perspiciatis, id veritatis?
                        </p1>
                </div>
                <div>
                    <button class="btn_1">MORE</button>
                </div>
            </div>

        </div>
    </div> -->

    <!-- <div class="wrapper">
        <div class="content">
            <div class="content__text">
                <div>
                    <h3 class="h3">Silk Road</h3>
                    <p class="p1">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet nesciunt sapiente laborum
                        doloribus aspernatur incidunt possimus rem exercitationem sint placeat ipsum fugit odit neque
                        quisquam, atque impedit quas beatae temporibus. Voluptatum, laborum optio dolor consectetur
                        corporis illo minima ex, fugit nulla quas veritatis aliquam aut nemo, dignissimos
                        necessitatibus. Quaerat, maiores.
                        </p1>
                </div>
                <div>
                    <button class="btn_1"><a href="https://ru.wikipedia.org/wiki/Silk_Road">START</a></button>
                </div>
            </div>
            <div class="content__image" style="width: 50%;">
                <img src="img/pic3.jpg" alt="" />
            </div>
        </div>
    </div> -->

    <!-- <div class="wrapper">
        <div class="gallery">
            <h2>Gallery</h2>
            <div class="pictures owl-carousel">
                <div class="pic_item">
                    <img src="img/pic4.jpg" height="200" alt="">
                    <div class="text_item">
                        <h4>Title</h4>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod aperiam laborum nisi.</p>
                        <button class="btn_2">MORE</button>
                    </div>
                </div>
                <div class="pic_item">
                    <img src="img/pic5.jpg" height="200" alt="">
                    <div class="text_item">
                        <h4>Title</h4>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod aperiam laborum nisi.</p>
                        <button class="btn_2">MORE</button>
                    </div>
                </div>
                <div class="pic_item">
                    <img src="img/pic6.jpg" height="200" alt="">
                    <div class="text_item">
                        <h4>Title</h4>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod aperiam laborum nisi.</p>
                        <button class="btn_2">MORE</button>
                    </div>
                </div>
                <div class="pic_item">
                    <img src="img/pic7.jpg" height="200" alt="">
                    <div class="text_item">
                        <h4>Title</h4>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod aperiam laborum nisi.</p>
                        <button class="btn_2">MORE</button>
                    </div>
                </div>
                <div class="pic_item">
                    <img src="img/pic8.jpeg" height="200" alt="">
                    <div class="text_item">
                        <h4>Title</h4>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod aperiam laborum nisi.</p>
                        <button class="btn_2">MORE</button>
                    </div>
                </div>
                <div class="pic_item">
                    <img src="img/pic9.jpg" height="200" alt="">
                    <div class="text_item">
                        <h4>Title</h4>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod aperiam laborum nisi.</p>
                        <button class="btn_2">MORE</button>
                    </div>
                </div>
            </div>
        </div>
    </div> -->

    <!-- <div class="wrapper">
        <div class="features">
            <h2>Features</h2>
            <div class="grid">
                <div class="item_1">
                    <img src="img/airplane-48.png" alt="">
                    <div class="grid_text_1">
                        <h4>One</h4>
                    </div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet, veritatis.</p>
                </div>
                <div class="item_2">
                    <img src="img/map_marker-48.png" alt="">
                    <div class="grid_text_2">
                        <h4>Two</h4>
                    </div>
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit, rerum.</p>
                </div>
                <div class="item_3">
                    <img src="img/movie-48.png" alt="">
                    <div class="grid_text_3">
                        <h4>Three</h4>
                    </div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet, veritatis.</p>
                </div>
                <div class="item_4">
                    <img src="img/alarm_clock-48.png" alt="">
                    <div class="grid_text_4">
                        <h4>Four</h4>
                    </div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet, veritatis.</p>
                </div>
                <div class="item_5">
                    <img src="img/face-48.png" alt="">
                    <div class="grid_text_5">
                        <h4>Five</h4>
                    </div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet, veritatis.</p>
                </div>
                <div class="item_6">
                    <img src="img/genius-48.png" alt="">
                    <div class="grid_text_6">
                        <h4>Six</h4>
                    </div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet, veritatis.</p>
                </div>
            </div>
        </div> -->
    <!-- </div> -->

        <!-- <div class="wrapper">
            <div class="forms">
                <h2>Write to us</h2>
                <form action="/search" method="POST">
                    <ul>
                        <li>
                            <legend><strong>Name: </strong></legend>
                            <input type="text" name="" id="" placeholder="">
                        </li>
                        <li>
                            <legend><strong>E-mail: </strong></legend>
                            <input type="email" name="" id="" placeholder="">
                        </li>
                        <li>
                            <legend><strong>Phone: </strong></legend>
                            <input type="email" name="" id="" placeholder="">
                        </li>
                    </ul>
            </div>
            <div class="contact">
                <legend><strong>Contact me via: </strong></legend>

                <label for="method1">E-mail:</label>
                <input type="radio" name="select" id="method1">

                <label for="method2">Phone:</label>
                <input type="radio" name="select" id="method2">

                <label for="method3">Telegram:</label>
                <input type="radio" name="select" id="method3">
            </div>

            <div class="list">
                <legend><strong>Topic: </strong></legend>
                <input type="text" list="lst" placeholder="Post my story">
                <datalist id="lst">
                    <option value="Empty"></option>
                    <option value="Empty"></option>
                    <option value="Empty"></option>
                    <option value="Empty"></option>
                    <option value="Empty"></option>
                </datalist>
            </div>

            <div class="textarea">
                <legend><strong>Message: </strong></legend>
                <label for="umeasge"></label>
                <textarea name="userMessage" id="umeasge"></textarea>
            </div>

            <div class="checkbox">
                <legend>I am a human </legend>
                <input type="checkbox" name="news" id="news">
            </div>
            <div>
                <button class="btn_1">SEND</button>
            </div>
            </form>

            <br>

            <hr> -->

            <!-- <footer class="footer">
                <ul class="social-icons-2">
                    <li class="social-icon tw"><a href="http://www.twitter.com"><img src="img/twitter-128.png"
                                style="height: 24px; width: 24px;" /></a></li>
                    <li class="social-icon fb"><a href="http://www.facebook.com"><img src="img/facebook-128.png"
                                style="height: 24px; width: 24px;" /></a></li>
                    <li class="social-icon inst"><a href="http://www.instagram.com"><img src="img/instagram-2-128.png"
                                style="height: 24px; width: 24px;" /></a></li>
                    <li class="social-icon you"><a href="http://www.youtube.com"><img src="img/youtube-128.png"
                                style="height: 24px; width: 24px;" /></a></li>
                    <li class="social-icon gml"><a href="http://www.gmail.com"><img src="img/gmail-128.png"
                                style="height: 24px; width: 24px;" /></a>
                    </li>
                </ul>
                <div class="footer_text">©UNTITELED 2019</div>
            </footer>
        </div>
    </div> -->

    <!-- <script src="jquery-3.6.0.min.js"></script>
    <script src="OwlCarousel2-2.3.4/dist/owl.carousel.min.js"></script>
    <script>
        $(document).ready(() => {
            $('.owl-carousel').owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                items: 4
            })
        })
    </script> -->
</body>

</html>
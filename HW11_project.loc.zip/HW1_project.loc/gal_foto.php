<?php


include ('./functions.php');
include('./foto.php');

$fotos_tmp = get_template('./templates/elements/gallery_list.php', ['fotos' => $fotos]);

$elements_tmp = [
    'header' => get_template('./templates/elements/header.php'),
    'fotos' => $fotos_tmp,    
    'footer' => get_template('./templates/elements/footer.php')
    ];

    $page_tmp = get_template('./templates/pages/fotos.php', $elements_tmp);

    $layout_tmp = get_template('./templates/layouts/main.php', ['page' => $page_tmp]);

    echo $layout_tmp;
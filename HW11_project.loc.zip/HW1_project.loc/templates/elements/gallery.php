<!-- <div class="wrapper">
        <div class="gallery">
            <h2>Gallery</h2> -->
            <!-- <div class="pictures owl-carousel"> -->
                <div class="pic_item">
                    <!-- <img src="img/pic4.jpg" height="200" alt=""> -->
                    <img src="<?php echo $img ?>" height="200" alt="">
                    <div class="text_item">
                        <h4><?php echo $title ?></h4>
                        <!-- <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod aperiam laborum nisi.</p> -->
                        <?php echo $slug ?>
                        <!-- <button class="btn_2">MORE</button> -->
                    </div>
                </div>
                <!-- <div class="pic_item">
                    <img src="img/pic5.jpg" height="200" alt="">
                    <div class="text_item">
                        <h4>Title</h4>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod aperiam laborum nisi.</p>
                        <button class="btn_2">MORE</button>
                    </div>
                </div>
                <div class="pic_item">
                    <img src="img/pic6.jpg" height="200" alt="">
                    <div class="text_item">
                        <h4>Title</h4>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod aperiam laborum nisi.</p>
                        <button class="btn_2">MORE</button>
                    </div>
                </div>
                <div class="pic_item">
                    <img src="img/pic7.jpg" height="200" alt="">
                    <div class="text_item">
                        <h4>Title</h4>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod aperiam laborum nisi.</p>
                        <button class="btn_2">MORE</button>
                    </div>
                </div>
                <div class="pic_item">
                    <img src="img/pic8.jpeg" height="200" alt="">
                    <div class="text_item">
                        <h4>Title</h4>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod aperiam laborum nisi.</p>
                        <button class="btn_2">MORE</button>
                    </div>
                </div>
                <div class="pic_item">
                    <img src="img/pic9.jpg" height="200" alt="">
                    <div class="text_item">
                        <h4>Title</h4>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod aperiam laborum nisi.</p>
                        <button class="btn_2">MORE</button>
                    </div> -->
                <!-- </div> -->
            <!-- </div> -->
        <!-- </div>
    </div> -->
<div class="wrapper">
        <div class="content">
            <div class="content__image" style="width: 40%;">
                <img src="<?php echo $img ?>" alt="" />
            </div>
            <div class="content__text">
                <div>
                    <h3 class="h3"><?php echo $title ?></h3>
                    <p class="p1">
                        <?php echo $slug ?>
                        </p1>
                </div>
                <div>
                    <button class="btn_1">MORE</button>
                </div>
            </div>

        </div>
    </div>
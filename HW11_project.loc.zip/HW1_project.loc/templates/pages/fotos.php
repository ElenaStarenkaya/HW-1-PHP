<?php

echo $header;
echo $fotos;
echo $footer;